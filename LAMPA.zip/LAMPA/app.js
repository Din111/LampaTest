
$(".nav-meni").click(function(e){
	$(".hidden").removeClass("hidden")
	e.currentTarget.className += " hidden"
})

